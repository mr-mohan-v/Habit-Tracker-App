package com.example.habit_speed_code

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
